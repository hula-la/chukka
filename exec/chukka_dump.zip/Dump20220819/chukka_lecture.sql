-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: chukka
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lecture`
--

DROP TABLE IF EXISTS `lecture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lecture` (
  `lec_id` int NOT NULL AUTO_INCREMENT,
  `day_and_time` varchar(255) DEFAULT NULL,
  `lec_category` int NOT NULL,
  `lec_contents` varchar(255) DEFAULT NULL,
  `lec_end_date` date DEFAULT NULL,
  `lec_genre` varchar(255) DEFAULT NULL,
  `lec_level` int NOT NULL,
  `lec_limit` int NOT NULL,
  `lec_notice` varchar(255) DEFAULT NULL,
  `lec_price` int NOT NULL,
  `lec_reg_date` date DEFAULT NULL,
  `lec_schedule` varchar(255) DEFAULT NULL,
  `lec_start_date` date DEFAULT NULL,
  `lec_student` int NOT NULL,
  `lec_thumb` varchar(255) DEFAULT NULL,
  `lec_title` varchar(255) DEFAULT NULL,
  `ins_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`lec_id`),
  KEY `FKn6pw2fkj9g1iadkj6bvtyndst` (`ins_id`),
  CONSTRAINT `FKn6pw2fkj9g1iadkj6bvtyndst` FOREIGN KEY (`ins_id`) REFERENCES `instructor` (`ins_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lecture`
--

LOCK TABLES `lecture` WRITE;
/*!40000 ALTER TABLE `lecture` DISABLE KEYS */;
INSERT INTO `lecture` VALUES (1,'월 09:00',0,NULL,'2022-10-14','k-pop',3,10,'이번주는 정상적으로 진행하겠습니다!',100,'2022-09-05','4주 주 1회','2022-09-19',3,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/1','Chungha - Sparkling','lovejin'),(2,'월/수 20:00',0,'IVE의 세계로 뛰어들고 싶나요? 자, 이제 여러분은 오리지널 안무가인 LeeYeon 강사로부터 오리지널 안무를 배우면 됩니다!','2022-10-31','k-pop',2,13,'이번주는 정상적으로 진행하겠습니다!',100,'2022-09-26','4주 주 2회','2022-10-10',3,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/2','IVE - Love Dive','leeyeon'),(3,'수/목 18:00',0,'팝콘처럼 팡팡 터지는 나연의 POP! LoveJin 강사로부터 안무를 배워볼까요?','2022-10-24','k-pop',1,12,'이번주는 정상적으로 진행하겠습니다!',100,'2022-09-12','4주 주 2회','2022-09-26',3,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/3','Nayeon - Pop','lovejin'),(4,'금/토 22:00',0,NULL,'2022-11-02','k-pop',2,15,'이번주는 정상적으로 진행하겠습니다!',100,'2022-09-21','4주 주 2회','2022-10-05',3,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/4','NewJeans - Attention','leeyeon'),(5,'토/일 20:00',0,'전 세계 최단기간 1억뷰 돌파! 월드클래스 BTS의 춤을 HoneyMoki 강사에게 배워봅시다.','2022-10-18','k-pop',2,12,'이번주는 정상적으로 진행하겠습니다!',100,'2022-09-08','4주 주 2회','2022-09-22',3,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/5','BTS - Dynamite','honeymoki'),(6,'월/수/금 17:00',0,NULL,'2022-10-15','k-pop',2,12,'이번주는 정상적으로 진행하겠습니다!',100,'2022-09-04','4주 주 3회','2022-09-18',3,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/6','TVXQ - Mirotic','honeymoki'),(7,'화/목 20:00',0,NULL,'2022-11-01','k-pop',2,5,'이번주는 정상적으로 진행하겠습니다!',100,'2022-09-20','4주 주 2회','2022-10-14',5,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/7','ITZY - Sneakers','lovejin'),(8,'월/수/금 19:00',0,NULL,'2022-10-29','k-pop',2,7,'이번주는 정상적으로 진행하겠습니다!',100,'2022-09-24','4주 주 3회','2022-10-08',3,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/8','Le Sserafim - Fearless','leeyeon'),(9,'화/목 10:00',0,NULL,'2022-10-22','k-pop',1,12,'이번주는 정상적으로 진행하겠습니다!',100,'2022-09-17','4주 주 2회','2022-10-01',3,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/9','IVE - Eleven','hoze'),(10,'수/금 10:00',0,NULL,'2022-10-27','k-pop',1,9,'이번주는 정상적으로 진행하겠습니다!',100,'2022-09-22','4주 주 2회','2022-10-06',3,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/10','Red Velvet - Feel My Rhythm','lovejin'),(11,NULL,1,'새롭게 돌아온 싸이! 유튜브를 휩쓴 그 노래! Hoze 강사와 함께 춰볼까요!','2022-10-14','hiphop',2,0,NULL,100,'2022-09-21','4주',NULL,0,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/11','Psy - That That','honeymoki'),(12,NULL,1,NULL,'2022-10-14','k-pop',1,100,NULL,100,'2022-09-08','4주',NULL,0,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/12','Aespa - Next Level','leeyeon'),(13,NULL,1,NULL,'2022-10-14','k-pop',1,100,NULL,100,'2022-09-04','4주',NULL,0,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/13','BTS - Butter','honeymoki'),(14,NULL,1,NULL,'2022-10-14','hiphop',3,100,NULL,100,'2022-09-20','4주',NULL,0,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/14','Aespa - Savage','leeyeon'),(15,NULL,1,NULL,'2022-10-14','hiphop',3,100,NULL,100,'2022-09-24','4주',NULL,0,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/15','NCT Dream - Beatbox','hoze'),(16,NULL,1,NULL,'2022-10-14','hiphop',1,100,NULL,100,'2022-09-17','4주',NULL,0,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/16','Blackpink - How you like that','hoze'),(17,NULL,1,NULL,'2022-10-14','k-pop',1,100,NULL,100,'2022-09-22','4주',NULL,0,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/17','Oh My Girl - Dun Dun Dance','lovejin'),(18,NULL,1,NULL,'2022-10-14','k-pop',2,100,NULL,100,'2022-09-05','4주',NULL,0,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/18','Seventeen - Darl+ing','honeymoki'),(19,NULL,1,NULL,'2022-10-14','k-pop',1,100,NULL,100,'2022-09-26','4주',NULL,0,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/19','Twice - Dance the night away','leeyeon'),(20,NULL,1,NULL,'2022-10-14','k-pop',3,100,NULL,100,'2022-09-12','4주',NULL,0,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/lecture/thumb/20','Hyun A - Change','hoze');
/*!40000 ALTER TABLE `lecture` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  8:20:36
