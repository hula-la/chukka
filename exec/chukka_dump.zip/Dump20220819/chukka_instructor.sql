-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: chukka
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `instructor`
--

DROP TABLE IF EXISTS `instructor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instructor` (
  `ins_id` varchar(255) NOT NULL,
  `ins_email` varchar(255) DEFAULT NULL,
  `ins_introduce` varchar(255) DEFAULT NULL,
  `ins_name` varchar(255) DEFAULT NULL,
  `ins_profile` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ins_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instructor`
--

LOCK TABLES `instructor` WRITE;
/*!40000 ALTER TABLE `instructor` DISABLE KEYS */;
INSERT INTO `instructor` VALUES ('honeymoki','honeymoki@ssafy.com','안녕하세요! 저는 현재 전 세계를 무대로 활동 중인 왁킹댄서 허니모키입니다. 현재 춤이 연일 화제가 되고 그 중에서도 \"왁킹\"이라는 장르의 관심도도 높아지며 분명 \"한번 배워볼까?\" \"하지만 어디서부터 어떻게 배우지?\" 하셨던 분들 계셨을 겁니다! 제가 바로 그 고민을 해결해 드리고자 CHUKKA로 찾아뵙게 되었습니다! 음악과 하나가 되어 손가락 하나하나까지 표현해낼 수 있는 개성 넘치는 이 멋진 춤 왁킹! 저와 함께 시작 해보실까요?','허니모키','https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/instructor/profile/honeymoki'),('hoze','hoze@ssafy.com','안녕하세요 wayC 크루의 리더 hoze입니다. 정통 힙합 크루 wayC의 힙합 코레오를 더 많은 분들과 함께하고 싶어서 이렇게 온라인 클래스를 준비하게 되었습니다! 크루원들마다의 코레오 스타일의 안무를 배워볼 수 있는 좋은 클래스가 될 것 같습니다. 많은 응원과 기대 부탁드릴게요:) 감사합니다!','hoze','https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/instructor/profile/hoze'),('leeyeon','leeyeon@ssafy.com','안녕하세요 XGY 아티스트 전담 안무가/댄서, K-POP 아티스트의 안무 디렉터로 활동하고 있는 리연입니다. 10년 이상의 아티스트 무대 경험과 아티스트/연습생 레슨 경력으로 여러분이 어렵게 생각했던 댄스에 쉽게 접근할 수 있게 해드릴게요.','리연','https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/instructor/profile/leeyeon'),('lovejin','lovejin@ssafy.com','2006년부터 활동을 시작한 저는 대한민국 유일의 국제라킹댄스대회 우승자 러브진입니다. 저는 스트릿 댄스의 종주국 미국에서 열린 댄스 올림픽 힙합 인터내셔널에 한국인 최초로 참가하여 우승까지 거머쥔 이력을 가지고 있습니다. 저는 오늘날까지도 퍼포먼스 연출, 컴피티션 무대 참가 및 입상, 이벤트 기획, 콘텐츠 제작 등 다양한 활동을 멈추지 않고 있습니다.','러브진','https://chukkadance.s3.ap-northeast-2.amazonaws.com/img/instructor/profile/lovejin');
/*!40000 ALTER TABLE `instructor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  8:20:36
