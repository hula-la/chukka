-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: chukka
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `snacks_reply`
--

DROP TABLE IF EXISTS `snacks_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `snacks_reply` (
  `reply_id` int NOT NULL AUTO_INCREMENT,
  `contents` varchar(255) DEFAULT NULL,
  `reply_regdate` date DEFAULT NULL,
  `snacks_id` bigint DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`reply_id`),
  KEY `FKsryq3gbyt5suvlkxufhbwkvm9` (`snacks_id`),
  KEY `FKoc1pqe0ubledtohy745rnkt6i` (`user_id`),
  CONSTRAINT `FKoc1pqe0ubledtohy745rnkt6i` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FKsryq3gbyt5suvlkxufhbwkvm9` FOREIGN KEY (`snacks_id`) REFERENCES `snacks` (`snacks_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snacks_reply`
--

LOCK TABLES `snacks_reply` WRITE;
/*!40000 ALTER TABLE `snacks_reply` DISABLE KEYS */;
INSERT INTO `snacks_reply` VALUES (1,'청바지가 잘 어울리시네요 :)','2022-01-02',1,'choi'),(2,'진짜 유연하시다 연체동물이세요?','2022-02-02',2,'kim'),(3,'춤선이 느낌있어요 어디에서 배우셨나요?','2022-03-02',3,'hong'),(4,'춤선이 느낌있어요 어디에서 배우셨나요?','2022-04-02',4,'yoon'),(5,'뒤에 분들은 같은 크루인가봐요 재밌어보여요','2022-05-02',5,'lee'),(6,'확실히 동작이 잘 보이네요 잘 봤습니다','2022-06-02',6,'hong'),(7,'스튜디오가 엄청 예술적이예요 멋있어요','2022-07-02',7,'choi'),(8,'저까지 같이 신나는 기분이에요','2022-08-02',8,'hong'),(9,'머리카락도 춤을 추는 거 같아요 잘 봤습니다','2022-09-02',9,'lee'),(10,'아..?','2022-10-02',10,'kim'),(11,'그게 맞지','2022-11-02',10,'hong'),(12,'살랑살랑 가볍게 잘 추시네요 :)','2022-11-02',11,'yoon');
/*!40000 ALTER TABLE `snacks_reply` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  8:20:36
