-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: chukka
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review` (
  `review_id` int NOT NULL AUTO_INCREMENT,
  `review_contents` varchar(255) DEFAULT NULL,
  `review_regdate` date DEFAULT NULL,
  `review_score` int NOT NULL,
  `lec_id` int DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`review_id`),
  KEY `FKrn1ml2nyectb5cd1tl2gcl1fp` (`lec_id`),
  KEY `FKiyf57dy48lyiftdrf7y87rnxi` (`user_id`),
  CONSTRAINT `FKiyf57dy48lyiftdrf7y87rnxi` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FKrn1ml2nyectb5cd1tl2gcl1fp` FOREIGN KEY (`lec_id`) REFERENCES `lecture` (`lec_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (1,'강사님이 너무 친절하시고 잘 가르쳐주세요','2022-09-01',5,5,'lee'),(2,'강의를 뒤입어 놓으셨다....','2022-09-01',4,5,'choi'),(3,'엄청난 강의! 유능한 강사!','2022-09-01',4,5,'hong'),(4,'지금 해외에 거주중인데 친구들이 K-Pop을 좋아해서 같이 배우게 됬어요!','2022-09-01',5,5,'choi'),(5,'이 춤을 배우고 인싸가 되었습니다','2022-09-01',5,5,'hong'),(6,'강사님이 너무 자세하게 잘 가르쳐주셔서 이해가 너무 잘 됩니다!!','2022-09-01',4,5,'hong'),(7,'주인 말을 듣지 않던 제 몸이 이제는 스스로 리듬을 탈 수 있게 되었어요 감사합니다','2022-09-01',5,5,'lee'),(8,'다음 수업이 너무 기대됩니다!','2022-09-01',4,5,'lee'),(9,'선생님이 실시간으로 자세하게 알려주셔서 너무 좋았습니다','2022-09-01',5,2,'lee'),(10,'좋은 강의, 좋은 강사였습니다!','2022-09-01',4,2,'choi'),(11,'천천히 차근차근 잘 알려주셔서 어려운 동작도 금세 따라할 수 있습니다!','2022-09-01',4,2,'hong'),(12,'이 수업을 듣기 전까지만 해도 친구들이랑 재미로만 췄는데 전문적으로 배울 수 있어 좋았습니다.','2022-09-01',3,2,'hong'),(13,'이 수업을 듣고 학교에서 유명인이 되었습니다.','2022-09-01',4,2,'hong'),(14,'요새 유행하는 춤인데 쉽게 배울 수 있어서 좋았습니다','2022-09-01',4,2,'kim'),(15,'노래는 너무 신나는데 춤이 너무 어려워요','2022-09-01',3,11,'kim'),(16,'간만에 싸이 노래 나와서 재밌게 배우고 갑니다','2022-09-01',4,11,'kim');
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  8:20:35
