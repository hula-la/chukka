-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: chukka
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `snacks`
--

DROP TABLE IF EXISTS `snacks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `snacks` (
  `snacks_id` bigint NOT NULL AUTO_INCREMENT,
  `snacks_contents` varchar(255) DEFAULT NULL,
  `snacks_like_cnt` bigint DEFAULT NULL,
  `snacks_regdate` date DEFAULT NULL,
  `snacks_title` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`snacks_id`),
  KEY `FKiflcd52g9sfdr75941hnl8ry6` (`user_id`),
  CONSTRAINT `FKiflcd52g9sfdr75941hnl8ry6` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `snacks`
--

LOCK TABLES `snacks` WRITE;
/*!40000 ALTER TABLE `snacks` DISABLE KEYS */;
INSERT INTO `snacks` VALUES (1,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/vid/snacks/1',3,'2022-01-01','현란한 골반 튕기기','kim'),(2,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/vid/snacks/2',2,'2022-02-01','이게 바로 웨이브다','lee'),(3,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/vid/snacks/3',5,'2022-03-01','두궁딱두궁딱','choi'),(4,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/vid/snacks/4',1,'2022-04-01','하루만에 만든 루틴','hong'),(5,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/vid/snacks/5',4,'2022-05-01','친구랑 같이 댄스챌린지','kim'),(6,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/vid/snacks/6',3,'2022-06-01','나 오늘 노랑 잘받는 듯','yoon'),(7,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/vid/snacks/7',3,'2022-07-01','포인트는 발 끝','lee'),(8,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/vid/snacks/8',7,'2022-08-01','난 코드짤 때 춤을 춰','choi'),(9,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/vid/snacks/9',5,'2022-09-01','살랑살랑','yoon'),(10,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/vid/snacks/10',3,'2022-10-01','이게 치명이지 그게 맞지','hong'),(11,'https://chukkadance.s3.ap-northeast-2.amazonaws.com/vid/snacks/11',3,'2022-11-01','오랜만에 야외 촬영','kim');
/*!40000 ALTER TABLE `snacks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-19  8:20:35
